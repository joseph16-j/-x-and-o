import { useEffect, useRef, useState } from 'react';
import { api, auth, ws } from '@appdeploy/client';
import { BarChart3, Settings, CircleHelp, Copy, LogIn, Volume2, VolumeX, Pause, RotateCcw, ArrowLeft, Users, X as XIcon, Circle, Search, Mail, LogOut } from 'lucide-react';

type Mark = 'X' | 'O';
type Mode = 'solo' | 'two' | 'online';
type Level = 'Beginner' | 'Easy' | 'Medium' | 'Hard' | 'Impossible';
type User = { userId: string; email?: string; name?: string };
type Profile = { userId: string; username: string; email?: string; preferredMark?: Mark };
type ChatMessage = { id:string; userId:string; name:string; text:string; createdAt:string };
type Room = { roomCode: string; ownerId: string; players: Array<{ userId: string; name: string; mark?: Mark }>; board: Array<Mark | null>; turn: Mark; startingMark?: Mark; phase: 'lobby' | 'playing' | 'finished' | 'disconnected'; winner?: Mark | 'draw'; disconnectReason?: string; lastSeen?: Record<string,number>; chatMessages?:ChatMessage[] };
type HeadToHeadMatch = { id:string; winnerName?:string; winner?:string; playedAt:string; players?:Array<{userId:string;name:string;mark?:Mark}>; result?:string };
type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> };
type Screen = 'home' | 'game' | 'friends' | 'stats' | 'settings' | 'help' | 'online' | 'account' | 'admin';

const levels: Level[] = ['Beginner', 'Easy', 'Medium', 'Hard', 'Impossible'];
const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
function result(board: Array<Mark | null>) {
  for (const [a,b,c] of lines) if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a] as Mark;
  return board.every(Boolean) ? 'draw' : null;
}
function tactical(board: Array<Mark | null>, mark: Mark) {
  for (const i of board.map((v,idx)=>v ? -1 : idx).filter(i=>i>=0)) { const next=[...board]; next[i]=mark; if (result(next)===mark) return i; }
  return null;
}
function minimax(board: Array<Mark | null>, maximizing: boolean): number {
  const r=result(board); if(r==='O') return 10; if(r==='X') return -10; if(r==='draw') return 0;
  const free=board.map((v,i)=>v?-1:i).filter(i=>i>=0);
  const scores=free.map(i=>{const next=[...board];next[i]=maximizing?'O':'X';return minimax(next,!maximizing);});
  return maximizing?Math.max(...scores):Math.min(...scores);
}
function pickBot(board: Array<Mark | null>, level: Level): number {
  const free=board.map((v,i)=>v?-1:i).filter(i=>i>=0); if(!free.length)return -1;
  if(level==='Impossible'||level==='Hard'){let best=-Infinity,move=free[0];for(const i of free){const next=[...board];next[i]='O';const score=minimax(next,false);if(score>best){best=score;move=i;}}return move;}
  if(level==='Medium'){const move=tactical(board,'O')??tactical(board,'X');if(move!==null)return move;}
  if(level==='Easy'){const block=tactical(board,'X');if(block!==null&&Math.random()>.3)return block;const attack=tactical(board,'O');if(attack!==null&&Math.random()>.25)return attack;}
  if(level==='Beginner'&&Math.random()<.55)return free[Math.floor(Math.random()*free.length)];
  return free[Math.floor(Math.random()*free.length)];
}

function App() {
  const [user,setUser]=useState<User|null>(null);
  const [screen,setScreen]=useState<Screen>('account');
  const [mode,setMode]=useState<Mode>('solo');
  const [level,setLevel]=useState<Level>('Beginner');
  const [board,setBoard]=useState<Array<Mark|null>>(Array(9).fill(null));
  const [turn,setTurn]=useState<Mark>('X');
  const [scores,setScores]=useState({X:0,O:0,draw:0});
  const [round,setRound]=useState(1);
  const [room,setRoom]=useState<Room|null>(null);
  const [headToHeadHistory,setHeadToHeadHistory]=useState<HeadToHeadMatch[]>([]);
  const [headToHeadScore,setHeadToHeadScore]=useState<{winsByUserId:Record<string,number>;draws:number;totalMatches:number}>({winsByUserId:{},draws:0,totalMatches:0});
  const [roomCode,setRoomCode]=useState('');
  const [chatMessages,setChatMessages]=useState<ChatMessage[]>([]);
  const [chatText,setChatText]=useState('');
  const [chatOpen,setChatOpen]=useState(true);
  const [emojiOpen,setEmojiOpen]=useState(false);
  const [emojiSearch,setEmojiSearch]=useState('');
  const [joiningRoom,setJoiningRoom]=useState(false);
  const [chatSending,setChatSending]=useState(false);
  const [name,setName]=useState('');
  const [profile,setProfile]=useState<Profile|null>(null);
  const [preferredMark,setPreferredMark]=useState<Mark>('X');
  const [adminOverview,setAdminOverview]=useState<{users:Profile[];matches:Array<{id:string;username:string;mode:string;result:string;opponent?:string;playedAt:string}>;activeRooms:Room[];pairHistory:Array<{player1Id:string;player1Name:string;player2Id:string;player2Name:string;played:number;player1Wins:number;player2Wins:number;draws:number;lastPlayedAt:string}>}|null>(null);
  const [adminLoading,setAdminLoading]=useState(false);
  const savedMatchRef=useRef<string>('');
  const [searchName,setSearchName]=useState('');
  const [foundProfiles,setFoundProfiles]=useState<Profile[]>([]);
  const [inviteData,setInviteData]=useState<{incoming:Array<{id:string;fromUserId:string;fromName:string;createdAt:string}>;outgoing:Array<{id:string;toUserId:string;toName:string;status:string;createdAt:string}>;friends:Array<{userId:string;username:string}>}>({incoming:[],outgoing:[],friends:[]});
  const seenInviteIds=useRef<Set<string>>(new Set());
  const musicGainRef=useRef<GainNode|null>(null);
  const customMusicGainRef=useRef<GainNode|null>(null);
  const musicElementRef=useRef<HTMLAudioElement|null>(null);
  const [globalMusicUrl,setGlobalMusicUrl]=useState('');
  const [globalMusicTitle,setGlobalMusicTitle]=useState('Synthesized game beat');
  const [musicUploadBusy,setMusicUploadBusy]=useState(false);
  const [musicUploadName,setMusicUploadName]=useState('');
  const musicOscRef=useRef<OscillatorNode|null>(null);
  const [notice,setNotice]=useState('');
  const [installPrompt,setInstallPrompt]=useState<InstallPromptEvent|null>(null);
  const [isInstalled,setIsInstalled]=useState(false);
  const [serviceWorkerReady,setServiceWorkerReady]=useState(false);
  const [winnerSaying,setWinnerSaying]=useState('');
  const [winnerSpeech,setWinnerSpeech]=useState('');
  const [paused,setPaused]=useState(false);
  const [sound,setSound]=useState(true);
  const [volume,setVolume]=useState(()=>{try{return Number(localStorage.getItem('native-xo-volume')||'85')}catch{return 85}});
  const volumeRef=useRef(85);
  useEffect(()=>{volumeRef.current=volume;try{localStorage.setItem('native-xo-volume',String(volume))}catch{}if(musicGainRef.current&&audioRef.current)musicGainRef.current.gain.setTargetAtTime(sound?volume/100*.42:0,audioRef.current.currentTime,.04);if(customMusicGainRef.current&&audioRef.current)customMusicGainRef.current.gain.setTargetAtTime(sound?volume/100*1.35:0,audioRef.current.currentTime,.04)},[volume,sound]);
  useEffect(()=>{let alive=true;const loadMusic=async()=>{try{const r=await api.get('/api/music');if(!alive)return;const music=r.data.music;if(music?.url){setGlobalMusicUrl((old:string)=>old===music.url?old:music.url);setGlobalMusicTitle(music.title||'Custom background music');}else{setGlobalMusicUrl('');setGlobalMusicTitle('Synthesized game beat');}}catch{}};void loadMusic();const timer=setInterval(()=>void loadMusic(),30000);return()=>{alive=false;clearInterval(timer);};},[]);
  const uploadGlobalMusic=async(file?:File)=>{if(!file)return;if(!file.type.startsWith('audio/')){setNotice('Choose an audio file such as MP3, WAV, or OGG.');return;}if(file.size>8*1024*1024){setNotice('Please choose an audio file under 8 MB.');return;}setMusicUploadBusy(true);setMusicUploadName(file.name);try{const dataUrl=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>typeof reader.result==='string'?resolve(reader.result):reject(new Error('Could not read audio file'));reader.onerror=()=>reject(new Error('Could not read audio file'));reader.readAsDataURL(file);});const base64=dataUrl.split(',')[1]||'';const r=await api.post('/api/music',{base64,contentType:file.type||'audio/mpeg',title:file.name.replace(/\\.[^.]+$/,'')||'Custom background music'});if(!r.data.saved)throw new Error('Upload was not saved');setNotice('Background music updated for all players.');const fresh=await api.get('/api/music');if(fresh.data.music?.url){setGlobalMusicUrl(fresh.data.music.url);setGlobalMusicTitle(fresh.data.music.title||file.name);}}catch(e){setNotice((e as {message?:string})?.message||'Could not upload music. Try an MP3 under 8 MB.');}finally{setMusicUploadBusy(false);}};
  const spokenOutcomeRef=useRef<string>('');
  const [twoTurn,setTwoTurn]=useState<Mark>('X');
  const connRef=useRef<ReturnType<typeof ws.connect>|null>(null);
  const roundTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const audioRef=useRef<AudioContext|null>(null);
  const activeBoard=mode==='online'&&room?room.board:board;
  const activeTurn=mode==='online'&&room?room.turn:mode==='two'?twoTurn:turn;
  const outcome=mode==='online'&&room?(room.phase==='finished'?(room.winner||result(room.board)):null):result(board);
  const myMark=mode==='online'&&room&&user?(room.players.find(p=>p.userId===user.userId)?.mark||'X'):'X';

  function playSound(kind:'move'|'win'|'draw'|'click'|'start') {
    if(!sound)return;
    try {
      const AudioCtor=window.AudioContext;
      if(!AudioCtor)return;
      const ctx=audioRef.current||new AudioCtor();audioRef.current=ctx;
      if(ctx.state==='suspended')void ctx.resume();
      const notes=kind==='win'?[659.25,783.99,987.77,1318.51,1567.98]:kind==='draw'?[392,349.23,329.63,261.63]:kind==='start'?[523.25,659.25,783.99]:kind==='click'?[880]:[kind==='move'?523.25:440];
      notes.forEach((freq,index)=>{const osc=ctx.createOscillator();const gain=ctx.createGain();osc.type=kind==='win'?'sine':'triangle';osc.frequency.value=freq;gain.gain.setValueAtTime(.0001,ctx.currentTime+index*.11);gain.gain.exponentialRampToValueAtTime(Math.max(.0002,(kind==='win'?.075:.035)*volumeRef.current/100),ctx.currentTime+index*.11+.02);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+index*.11+.34);osc.connect(gain);gain.connect(ctx.destination);osc.start(ctx.currentTime+index*.11);osc.stop(ctx.currentTime+index*.11+.36);});
    } catch {}
  }
    useEffect(()=>{
    const standaloneQuery=window.matchMedia('(display-mode: standalone)');
    const updateInstalled=()=>setIsInstalled(standaloneQuery.matches||Boolean((navigator as Navigator & {standalone?:boolean}).standalone));
    updateInstalled();
    standaloneQuery.addEventListener?.('change',updateInstalled);
    const onInstallAvailable=(event:Event)=>{
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const onInstalled=()=>{
      setInstallPrompt(null);
      setIsInstalled(true);
      setNotice('Native X & O has been installed on this device.');
    };
    window.addEventListener('beforeinstallprompt',onInstallAvailable);
    window.addEventListener('appinstalled',onInstalled);
    if('serviceWorker' in navigator){
      navigator.serviceWorker.ready
        .then(()=>setServiceWorkerReady(true))
        .catch((error)=>console.error('PWA service worker is not ready:',error));
      navigator.serviceWorker.addEventListener('controllerchange',()=>setServiceWorkerReady(true),{once:true});
    }
    return()=>{
      standaloneQuery.removeEventListener?.('change',updateInstalled);
      window.removeEventListener('beforeinstallprompt',onInstallAvailable);
      window.removeEventListener('appinstalled',onInstalled);
    };
  },[]);
  const installApp=async()=>{
    if(isInstalled){
      setNotice('Native X & O is already installed. Open it from your home screen.');
      return;
    }
    if(!window.isSecureContext){
      setNotice('Installation needs HTTPS. Open the official Native X & O app link in Chrome.');
      return;
    }

    if(installPrompt){
      try{
        await installPrompt.prompt();
        const choice=await installPrompt.userChoice;
        setInstallPrompt(null);
        setNotice(choice.outcome==='accepted'
          ? 'Installing Native X & O…'
          : 'Installation was cancelled. Tap Install App when you are ready.');
      }catch(error){
        console.error('Native X & O install prompt failed:',error);
        setInstallPrompt(null);
        setNotice('Chrome could not open the install window. Use Chrome menu ⋮ → Install app.');
      }
      return;
    }

    const isApple=/iphone|ipad|ipod/i.test(navigator.userAgent);
    const isAndroid=/android/i.test(navigator.userAgent);

    if(isApple){
      setNotice('On iPhone or iPad, open this page in Safari, tap Share, then Add to Home Screen.');
      return;
    }

    if('serviceWorker' in navigator){
      try{
        const registration=await navigator.serviceWorker.register('/service-worker.js',{scope:'/'});
        await navigator.serviceWorker.ready;
        setServiceWorkerReady(true);
        await registration.update();
      }catch(error){
        console.error('Native X & O service worker setup failed:',error);
        setNotice('The app could not finish preparing for installation. Open it in Chrome and refresh the page.');
        return;
      }
    }

    if(isAndroid){
      setNotice('To install: open this page in Google Chrome, tap ⋮ in the top-right, choose Install app (or Add to Home screen), then confirm Add. If this is inside another app, choose Open in Chrome first.');
      return;
    }

    setNotice('Open Native X & O in Chrome or Edge, then use the browser menu → Install app.');
  };
  useEffect(()=>{let alive=true;auth.getUser().then(async u=>{if(!alive||!u)return;setUser({userId:u.userId,email:u.email,name:u.name});setName(u.name||u.email?.split('@')[0]||'Player');try{const p=await api.get('/api/profile');if(alive&&p.data.profile){setProfile(p.data.profile);setName(p.data.profile.username);setPreferredMark(p.data.profile.preferredMark||'X');setScreen('home');}else if(alive)setScreen('account');}catch{if(alive)setScreen('account');}}).catch(()=>{});return()=>{alive=false;};},[]);
  useEffect(()=>{if(!user||connRef.current)return;const conn=ws.connect();connRef.current=conn;conn.onMessage(msg=>{if(msg?.type==='entity.update'&&msg.payload?.entity_type==='xo-room'&&msg.payload.data)setRoom(msg.payload.data as Room);});return()=>{conn.disconnect();connRef.current=null;};},[user]);
  useEffect(()=>{if(!room||!connRef.current)return;let cancelled=false;(async()=>{try{const c=connRef.current!;await c.ready;if(cancelled)return;if(c.connectionId)await api.post('/api/subscriptions',{entity_type:'xo-room',entity_id:room.roomCode,connection_id:c.connectionId});}catch{}})();return()=>{cancelled=true;const c=connRef.current;if(c?.connectionId)api.post('/api/subscriptions/remove',{entity_type:'xo-room',entity_id:room.roomCode,connection_id:c.connectionId}).catch(()=>{});};},[room?.roomCode]);
  useEffect(()=>{if(!room||!user||!['playing','lobby'].includes(room.phase))return;let alive=true;const ping=async()=>{try{const r=await api.post('/api/rooms/'+room.roomCode+'/presence',{});if(alive)setRoom(r.data.room);}catch{}};void ping();const timer=setInterval(()=>{void ping();},8000);return()=>{alive=false;clearInterval(timer);};},[room?.roomCode,room?.phase,user?.userId]);
  useEffect(()=>{if(!room||!user)return;let alive=true;api.get('/api/rooms/'+room.roomCode+'/history').then(r=>{if(alive){setHeadToHeadHistory(r.data.history||[]);setHeadToHeadScore(r.data.scoreline||{winsByUserId:{},draws:0,totalMatches:0});}}).catch(()=>{});return()=>{alive=false;};},[room?.roomCode,room?.phase,room?.winner]);
  useEffect(()=>{setChatMessages(room?.chatMessages||[]);},[room?.roomCode,room?.chatMessages]);
  useEffect(()=>{if(!outcome||screen!=='game'||mode==='online')return;playSound(outcome==='draw'?'draw':'win');setScores(s=>({...s,[outcome]:s[outcome as 'X'|'O'|'draw']+1}));const signature=mode+':'+round+':'+outcome+':'+board.join('');if(savedMatchRef.current!==signature){savedMatchRef.current=signature;api.post('/api/matches',{mode,result:outcome,opponent:mode==='solo'?'Computer':'Local player 2',board}).catch(()=>{});}if(roundTimer.current)clearTimeout(roundTimer.current);roundTimer.current=setTimeout(()=>{setBoard(Array(9).fill(null));setTurn('X');setTwoTurn('X');setRound(n=>n+1);setPaused(false);},2200);return()=>{if(roundTimer.current)clearTimeout(roundTimer.current);};},[outcome,screen,mode]);
  const startNextOnlineRound=async()=>{if(!room||room.phase!=='finished')return;try{const r=await api.post('/api/rooms/'+room.roomCode+'/action',{action:'next-round'});setRoom(r.data.room);setRound(n=>n+1);playSound('start');}catch{setNotice('The next round could not start. Please try again.')}};
  useEffect(()=>{if(mode!=='online'||!room||room.phase!=='finished'||!room.winner)return;const key=room.roomCode+':'+room.board.join('')+':'+room.winner;if(spokenOutcomeRef.current===key)return;spokenOutcomeRef.current=key;const winnerPlayer=room.players.find(p=>p.mark===room.winner);const exactAnnouncement=room.winner==='draw'?'Draw game! Great match.':winnerPlayer?'Winner! '+winnerPlayer.name+' wins!':'Match finished!';setWinnerSpeech(exactAnnouncement);setWinnerSaying(room.winner==='draw'?'🤝 DRAW GAME!':'🏆 WINNER: '+(winnerPlayer?.name||room.winner)+'!');try{if('speechSynthesis' in window){window.speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(exactAnnouncement);utterance.lang='en-NG';const voices=window.speechSynthesis.getVoices();const nigerianVoice=voices.find(v=>/en-NG/i.test(v.lang))||voices.find(v=>/Nigeria/i.test(v.name));if(nigerianVoice)utterance.voice=nigerianVoice;utterance.rate=1.12;utterance.pitch=1.02;utterance.volume=1;window.speechSynthesis.speak(utterance);}}catch{}playSound('win');void api.get('/api/rooms/'+room.roomCode+'/history').then(response=>{const score=response.data.scoreline;if(score){setHeadToHeadHistory(response.data.history||[]);setHeadToHeadScore(score);const xPlayer=room.players.find(p=>p.mark==='X');const oPlayer=room.players.find(p=>p.mark==='O');const scoreText=' · '+(xPlayer?.name||'X')+' '+(score.winsByUserId[xPlayer?.userId||'']||0)+' – '+(score.winsByUserId[oPlayer?.userId||'']||0)+' '+(oPlayer?.name||'O')+' · Draws '+score.draws;setWinnerSaying((room.winner==='draw'?'🤝 DRAW GAME!':'🏆 WINNER: '+(winnerPlayer?.name||room.winner)+'!')+scoreText);}}).catch(()=>{});},[room?.phase,room?.winner,room?.board,mode]);
  const signIn=async()=>{try{const r=await auth.signIn({scope:'openid email profile offline_access'});setUser({userId:r.user.userId,email:r.user.email,name:r.user.name});setName(r.user.name||r.user.email?.split('@')[0]||'Player');try{const p=await api.get('/api/profile');if(p.data.profile){setProfile(p.data.profile);setName(p.data.profile.username);setPreferredMark(p.data.profile.preferredMark||'X');setScreen('home');}else setScreen('account');}catch{setScreen('account');}setNotice('Account verified. Create or save your player profile to continue.');}catch(e){const code=(e as {code?:string})?.code;setNotice(code==='popup_blocked'?'Allow pop-ups to sign in with Google.':code==='popup_closed'?'Sign-in was cancelled.':'Sign-in could not be completed. Please try again.');}};
  const saveProfile=async()=>{if(!user){setNotice('Sign in with Google first.');return;}const username=name.trim();if(username.length<3||username.length>20){setNotice('Choose a username between 3 and 20 characters.');return;}try{const r=await api.post('/api/profile',{username,preferredMark});setProfile(r.data.profile);setName(r.data.profile.username);setPreferredMark(r.data.profile.preferredMark||'X');setScreen('home');setNotice('Player profile saved. Welcome to Native X & O!');playSound('start');}catch(e){setNotice((e as {message?:string})?.message||'Could not save that username. Try another.');}};
  const signOut=async()=>{await auth.signOut();setUser(null);setProfile(null);setRoom(null);setScreen('account');setNotice('You have signed out.');};
  const startGame=(newMode:Mode)=>{if(!user||!profile){setScreen('account');setNotice('Create your account and player profile before playing.');return;}setMode(newMode);setBoard(Array(9).fill(null));setTurn('X');setTwoTurn(preferredMark);setPaused(false);setNotice('');setRoom(null);setRound(1);setScores({X:0,O:0,draw:0});setScreen(newMode==='online'?'online':'game');playSound('start');};
  const localMove=(i:number)=>{if(paused||board[i]||result(board))return;if(mode==='two'){const next=[...board];next[i]=twoTurn;setBoard(next);playSound('move');if(!result(next))setTwoTurn(twoTurn==='X'?'O':'X');return;}if(turn!=='X')return;const next=[...board];next[i]='X';setBoard(next);playSound('move');if(result(next))return;setTurn('O');setTimeout(()=>{const m=pickBot(next,level);if(m<0)return;const bot=[...next];bot[m]='O';setBoard(bot);playSound('move');setTurn('X');},420);};
  const reset=()=>{setBoard(Array(9).fill(null));setTurn('X');setTwoTurn(preferredMark);setPaused(false);setNotice('');if(mode==='online'&&room)api.post('/api/rooms/'+room.roomCode+'/action',{action:'next-round'}).then(r=>setRoom(r.data.room)).catch(()=>{});playSound('click');};
  useEffect(()=>{if(!user||!profile)return;let alive=true;const refreshInvites=async()=>{try{const r=await api.get('/api/invites');if(!alive)return;const data=r.data;const incoming=data.incoming||[];for(const invite of incoming){if(!seenInviteIds.current.has(invite.id)){seenInviteIds.current.add(invite.id);setNotice('New game invitation from '+invite.fromName+'. Open Friends to accept or decline.');}}setInviteData({incoming,outgoing:data.outgoing||[],friends:data.friends||[]});}catch{}};void refreshInvites();const timer=setInterval(()=>{void refreshInvites();},3000);return()=>{alive=false;clearInterval(timer);};},[user?.userId,profile?.userId]);
  useEffect(()=>{
    if(!sound||globalMusicUrl)return;
    let alive=true;
    let beatTimer:ReturnType<typeof setInterval>|null=null;
    let duckTimer:ReturnType<typeof setInterval>|null=null;
    let step=0;
    const startMusic=()=>{
      if(!alive)return;
      try{
        const Ctx=window.AudioContext;
        if(!Ctx)return;
        const ctx=audioRef.current||new Ctx();
        audioRef.current=ctx;
        void (ctx.state==='suspended'?ctx.resume():Promise.resolve()).then(()=>{
          if(!alive||ctx.state!=='running'||musicOscRef.current)return;
          const master=ctx.createGain();
          const limiter=ctx.createDynamicsCompressor();
          limiter.threshold.value=-10;limiter.knee.value=8;limiter.ratio.value=8;limiter.attack.value=.003;limiter.release.value=.18;
          master.gain.value=volumeRef.current/100*.42;
          master.connect(limiter);limiter.connect(ctx.destination);
          musicGainRef.current=master;
          musicOscRef.current=ctx.createOscillator();
          musicOscRef.current.type='triangle';
          musicOscRef.current.frequency.value=110;
          const bassGain=ctx.createGain();
          bassGain.gain.value=.07;
          musicOscRef.current.connect(bassGain);
          bassGain.connect(master);
          musicOscRef.current.start();
          const kick=(time:number)=>{const o=ctx.createOscillator();const g=ctx.createGain();o.type='sine';o.frequency.setValueAtTime(115,time);o.frequency.exponentialRampToValueAtTime(52,time+.11);g.gain.setValueAtTime(.0001,time);g.gain.exponentialRampToValueAtTime(.32,time+.012);g.gain.exponentialRampToValueAtTime(.0001,time+.15);o.connect(g);g.connect(master);o.start(time);o.stop(time+.16);};
          const snare=(time:number)=>{const o=ctx.createOscillator();const g=ctx.createGain();o.type='sine';o.frequency.setValueAtTime(210,time);o.frequency.exponentialRampToValueAtTime(135,time+.055);g.gain.setValueAtTime(.0001,time);g.gain.exponentialRampToValueAtTime(.07,time+.008);g.gain.exponentialRampToValueAtTime(.0001,time+.075);o.connect(g);g.connect(master);o.start(time);o.stop(time+.08);};
          const hat=(time:number)=>{const o=ctx.createOscillator();const g=ctx.createGain();o.type='sine';o.frequency.value=5200;g.gain.setValueAtTime(.0001,time);g.gain.exponentialRampToValueAtTime(.009,time+.004);g.gain.exponentialRampToValueAtTime(.0001,time+.022);o.connect(g);g.connect(master);o.start(time);o.stop(time+.025);};
          const bass=[55,55,73.42,55,65.41,65.41,82.41,65.41];
          beatTimer=setInterval(()=>{
            if(!alive)return;
            const now=ctx.currentTime;
            const barStep=step%16;
            if(barStep%4===0)kick(now);
            if(barStep===4||barStep===12)snare(now);
            if(barStep%2===0)hat(now);
            musicOscRef.current?.frequency.setTargetAtTime(bass[Math.floor(barStep/2)%bass.length],now,.025);
            step++;
          },125);
          duckTimer=setInterval(()=>{
            if(!alive||!musicGainRef.current)return;
            const speaking='speechSynthesis' in window&&window.speechSynthesis.speaking;
            musicGainRef.current.gain.setTargetAtTime(speaking?volumeRef.current/100*.18:volumeRef.current/100*.42,ctx.currentTime,.08);
          },180);
        });
      }catch{}
    };
    const tap=(event:Event)=>{
      startMusic();
      const target=event.target as HTMLElement|null;
      if(!target||!target.closest('button,[role="button"],select,input,a'))return;
      try{
        const Ctx=window.AudioContext;
        if(!Ctx)return;
        const ctx=audioRef.current||new Ctx();audioRef.current=ctx;
        void (ctx.state==='suspended'?ctx.resume():Promise.resolve()).then(()=>{
          if(!alive||ctx.state!=='running')return;
          const osc=ctx.createOscillator();const gain=ctx.createGain();
          osc.type='sine';osc.frequency.setValueAtTime(920,ctx.currentTime);osc.frequency.exponentialRampToValueAtTime(560,ctx.currentTime+.055);
          gain.gain.setValueAtTime(.0001,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(Math.max(.0002,.045*volumeRef.current/100),ctx.currentTime+.006);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.075);
          osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+.07);
        });
      }catch{}
    };
    document.addEventListener('pointerdown',tap,true);
    document.addEventListener('keydown',startMusic,true);
    startMusic();
    return()=>{alive=false;document.removeEventListener('pointerdown',tap,true);document.removeEventListener('keydown',startMusic,true);if(beatTimer)clearInterval(beatTimer);if(duckTimer)clearInterval(duckTimer);if(musicGainRef.current&&audioRef.current)musicGainRef.current.gain.setTargetAtTime(0,audioRef.current.currentTime,.1);if(musicOscRef.current){try{musicOscRef.current.stop();}catch{}musicOscRef.current=null;}};
  },[sound,globalMusicUrl]);
  useEffect(()=>{if(!globalMusicUrl||!sound)return;let alive=true;let element:HTMLAudioElement|null=null;try{const ctx=audioRef.current||new AudioContext();audioRef.current=ctx;element=new Audio(globalMusicUrl);element.loop=true;element.preload='auto';element.volume=1;musicElementRef.current=element;const source=ctx.createMediaElementSource(element);const gain=ctx.createGain();const limiter=ctx.createDynamicsCompressor();limiter.threshold.value=-5;limiter.knee.value=6;limiter.ratio.value=12;limiter.attack.value=.003;limiter.release.value=.2;gain.gain.value=volumeRef.current/100*1.35;source.connect(gain);gain.connect(limiter);limiter.connect(ctx.destination);customMusicGainRef.current=gain;const start=()=>{if(!alive)return;if(ctx.state==='suspended')void ctx.resume();void element?.play().catch(()=>{});};document.addEventListener('pointerdown',start,true);document.addEventListener('keydown',start,true);start();return()=>{alive=false;document.removeEventListener('pointerdown',start,true);document.removeEventListener('keydown',start,true);if(element){element.pause();element.src='';}musicElementRef.current=null;customMusicGainRef.current=null;};}catch{if(element){element.pause();element.src='';}return;}},[globalMusicUrl,sound]);
  const sendInvite=async(toUserId:string,playerName:string)=>{try{const r=await api.post('/api/invites',{toUserId});setNotice(r.data.savedFriend?playerName+' is already saved in your friends list.':r.data.alreadyPending?'An invitation is already waiting for this player.':'Game invitation sent to '+playerName+'.');const list=await api.get('/api/invites');setInviteData({incoming:list.data.incoming||[],outgoing:list.data.outgoing||[],friends:list.data.friends||[]});}catch(e){setNotice((e as {message?:string})?.message||'Could not send invitation. Please try again.');}};
  const respondInvite=async(id:string,decision:'accept'|'decline',fromName:string)=>{try{await api.post('/api/invites/'+encodeURIComponent(id)+'/respond',{decision});setNotice(decision==='accept'?'Invitation accepted. '+fromName+' has been saved to your friends for next time.':'Invitation declined.');const list=await api.get('/api/invites');setInviteData({incoming:list.data.incoming||[],outgoing:list.data.outgoing||[],friends:list.data.friends||[]});}catch(e){setNotice((e as {message?:string})?.message||'Could not respond to invitation.');}};
  useEffect(()=>{if(screen!=='admin')return;let alive=true;const refresh=async()=>{try{const r=await api.get('/api/admin/overview');if(alive)setAdminOverview(r.data);}catch{}};void refresh();const timer=setInterval(()=>{void refresh();},2000);return()=>{alive=false;clearInterval(timer);};},[screen]);
  const openAdmin=async()=>{setAdminLoading(true);setScreen('admin');try{const r=await api.get('/api/admin/overview');setAdminOverview(r.data);}catch{setNotice('Admin access is restricted to the registered administrator account.');setScreen('home');}finally{setAdminLoading(false);}};
  const makeRoom=async()=>{if(!user||!profile){setScreen('account');return;}try{const r=await api.post('/api/rooms',{name:profile.username,preferredMark});setRoom(r.data.room);setMode('online');setBoard(Array(9).fill(null));setNotice('Room created. Share the code below; the match will play on this same board as Quick Match.');setScreen('game');}catch{setNotice('Could not create room. Please try again.');}};
  const joinRoom=async()=>{if(!user||!profile){setScreen('account');return;}const code=roomCode.trim().toUpperCase();if(!code||joiningRoom)return;setJoiningRoom(true);setNotice('Connecting to room…');try{const r=await api.post('/api/rooms/'+encodeURIComponent(code)+'/join',{name:profile.username});setRoom(r.data.room);setMode('online');setScreen('game');setNotice(r.data.room.phase==='playing'?'Connected — match resumed.':'Connected — waiting for the host to start.');}catch(e){setNotice((e as {message?:string})?.message||'Room not found or already started. Check the code.');}finally{setJoiningRoom(false);}};
  const sendChat=async(textOverride?:string)=>{if(!room||!user||chatSending)return;const text=(textOverride??chatText).trim();if(!text||text.length>500)return;setChatSending(true);try{const r=await api.post('/api/rooms/'+room.roomCode+'/chat',{text});setRoom(r.data.room);setChatMessages(r.data.room.chatMessages||[]);setChatText('');setEmojiOpen(false);}catch(e){setNotice((e as {message?:string})?.message||'Message could not be sent. Try again.');}finally{setChatSending(false);}};
  const emojiGroups=[{name:'Smileys',items:['😀','😃','😄','😁','😆','😅','😂','🤣','🥲','😊','😇','🙂','🙃','😉','😍','🥰','😘','😗','😙','😚','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🫢','🤫','🤔','🫡','🤐','🤨','😐','😑','😶','🫥','😏','😒','🙄','😬','😮‍💨','🤥','😌','😔','😪','🤤','😴','😷','🤒','🤕','🤢','🤮','🥵','🥶','🥴','😵','🤯','🥳','🥸','😎','🤓','🧐']},{name:'Emotions',items:['😕','🫤','😟','🙁','☹️','😮','😯','😲','😳','🥺','🥹','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀','☠️','💩','🤡','👻','👽','👾','🤖','🎃']},{name:'Hands & people',items:['👋','🤚','🖐️','✋','🖖','🫱','🫲','🫳','🫴','👌','🤌','🤏','✌️','🤞','🫰','🤟','🤘','🤙','👈','👉','👆','👇','☝️','👍','👎','✊','👊','🤛','🤜','👏','🙌','👐','🤲','🤝','🙏','✍️','💪','🦾','🫶','❤️‍🔥']},{name:'Hearts',items:['❤️','🧡','💛','💚','💙','🩵','💜','🤎','🖤','🩶','🤍','💔','❣️','💕','💞','💓','💗','💖','💘','💝','💟','♥️','💌','💋']},{name:'Celebration',items:['🎉','🎊','🎈','🎂','🏆','🥇','🥈','🥉','🏅','🎖️','⚽','🏀','🏈','⚾','🎾','🏐','🎮','🕹️','🎯','🎲','🎵','🎶','🔥','✨','⭐','🌟','💫','🚀','💥','💯','✅','❌','💎']},{name:'Animals & nature',items:['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐮','🐷','🐸','🐵','🙈','🙉','🙊','🐔','🐧','🐦','🦄','🐝','🦋','🐢','🐍','🐬','🐳','🦈','🦖','🌸','🌹','🌻','🌈','☀️','🌙','⚡','❄️','🌊']},{name:'Food & drink',items:['🍏','🍎','🍐','🍊','🍋','🍌','🍉','🍇','🍓','🫐','🍒','🍑','🥭','🍍','🥥','🥑','🍕','🍔','🍟','🌭','🍿','🧂','🥓','🍗','🍖','🌮','🌯','🥪','🍜','🍣','🍩','🍪','🎂','🍫','🍬','☕','🧃','🥤']},{name:'Travel & objects',items:['🚗','🚕','🚌','🚎','🏎️','🚓','🚑','🚒','🚀','✈️','🚁','🚢','🚲','🏠','🏡','🏰','🗽','🎁','🎀','📱','💻','⌚','📷','💡','🔑','🔒','💰','💵','📣','🔔','📌','✉️','📦']},{name:'Symbols & flags',items:['❤️','☮️','✝️','☯️','♻️','⚜️','🔱','〽️','‼️','⁉️','❓','❗','⭕','🚫','🔞','🆗','🆕','🆙','🆒','🆓','🇳🇬','🇬🇭','🇿🇦','🇰🇪','🇺🇸','🇬🇧','🇨🇦','🇮🇳','🇧🇷','🇯🇵','🇫🇷','🇩🇪','🇪🇸','🇮🇹']}];
  const findFriend=async()=>{if(!searchName.trim())return;try{const r=await api.get('/api/profiles/search?username='+encodeURIComponent(searchName.trim()));setFoundProfiles(r.data.profiles||[]);if(!r.data.profiles?.length)setNotice('No player found with that username yet.');}catch{setNotice('Could not search players right now.');}};
  const startOnline=async()=>{if(!room)return;try{const r=await api.post('/api/rooms/'+room.roomCode+'/action',{action:'start'});setRoom(r.data.room);setScreen('game');playSound('start');}catch{setNotice('Either player can start when both players have joined.');}};
  const onlineMovePending=useRef(false);
  const moveOnline=async(i:number)=>{if(!room||onlineMovePending.current||room.board[i]||room.phase!=='playing'||room.turn!==myMark)return;const currentRoom=room;const nextBoard=[...room.board];nextBoard[i]=myMark;const nextResult=result(nextBoard);const optimisticRoom:Room={...room,board:nextBoard,turn:myMark==='X'?'O':'X',phase:'playing',winner:undefined};onlineMovePending.current=true;setRoom(optimisticRoom);playSound('move');try{const r=await api.post('/api/rooms/'+room.roomCode+'/move',{index:i});setRoom(r.data.room);}catch{try{const latest=await api.get('/api/rooms/'+currentRoom.roomCode);setRoom(latest.data.room);}catch{setRoom(currentRoom);}setNotice('Move could not sync. Board refreshed; please try again.');}finally{onlineMovePending.current=false;}};
  const goHome=()=>{setScreen('home');setPaused(false);setNotice('');};
  const boardView=(cells:Array<Mark|null>,onMove:(i:number)=>void)=><div className="arena-grid">{cells.map((cell,i)=><button aria-label={'Cell '+(i+1)+(cell?' '+cell:' empty')} key={i} className={'arena-cell '+(cell||'')} onClick={()=>onMove(i)}>{cell==='X'?<XIcon/>:cell==='O'?<Circle/>:null}</button>)}</div>;
  const statusText=outcome==='draw'?'DRAW GAME':outcome?outcome+' WINS':activeTurn+"'S TURN";
  return <div className="native-shell">
    <header className="native-header">{screen!=='home'&&<button className="back-button" onClick={goHome}><ArrowLeft/></button>}<div className="header-title">NATIVE X &amp; O</div><div className="header-right">{user?<span className="user-name">{profile?.username||name}</span>:<button className="signin" onClick={signIn}><LogIn size={16}/> Sign in</button>}</div></header>
    {!user&&<main className="sub-screen account-screen"><section className="section-heading"><h1>NATIVE X &amp; O</h1><p>Sign in or create an account before playing.</p></section><div className="logo-art"><div className="logo-tile tile-x"><XIcon/></div><div className="logo-tile tile-o"><Circle/></div></div><div className="online-card"><h2>Your player account</h2><p>Choose Apple or Google to securely verify your account. Your password is entered only on the provider's sign-in page, never inside this game.</p><button className="big-button quick" onClick={signIn}><LogIn size={18}/> CONTINUE WITH APPLE OR GOOGLE</button><p className="small-note">You must sign in and save a player profile before accessing the game.</p></div></main>}
    {user&&!profile&&<main className="sub-screen account-screen"><section className="section-heading"><h1>CREATE YOUR PROFILE</h1><p>One account, one player name. Then you're ready to play.</p></section><div className="logo-art"><div className="logo-tile tile-x"><XIcon/></div><div className="logo-tile tile-o"><Circle/></div></div><div className="online-card"><label className="field-label">GMAIL ACCOUNT</label><div className="email-readonly">{user.email||'Google account verified'}</div><label className="field-label">PLAYER USERNAME</label><input value={name} onChange={e=>setName(e.target.value)} maxLength={20} placeholder="Choose username"/><button className="big-button quick" onClick={saveProfile}>CREATE / SAVE PROFILE</button><button className="big-button secondary-button" onClick={installApp}>{isInstalled?'INSTALLED':installPrompt?'INSTALL APP':'ADD TO PHONE'}</button><button className="big-button secondary-button" onClick={signOut}><LogOut size={17}/> SIGN OUT</button></div></main>}
    {screen==='home'&&user&&profile&&<main className="home-screen">
      <section className="logo-block"><h1>NATIVE X &amp; O</h1><p className="creator">CREATED BY JOSEPH UWAKWE</p><p className="tagline">FUTURISTIC METALLIC GLASS ARENA</p><div className="logo-art"><div className="logo-tile tile-x"><XIcon/></div><div className="logo-tile tile-o"><Circle/></div></div></section>
      <button className="big-button quick" onClick={()=>startGame('solo')}>PLAY QUICK MATCH</button><button className="big-button multiplayer" onClick={()=>startGame('online')}>ONLINE MULTIPLAYER</button><button className="big-button friends" onClick={()=>setScreen('friends')}>FRIENDS</button>
      <div className="home-grid"><button onClick={()=>startGame('solo')}>VS COMPUTER</button><button onClick={()=>startGame('two')}>TWO PLAYERS</button><button onClick={()=>setScreen('friends')}>CHALLENGES</button><button onClick={()=>setScreen('stats')}>TOURNAMENT</button></div>
      <div className="bottom-icons"><button aria-label="Statistics" onClick={()=>setScreen('stats')}><BarChart3/></button><button aria-label="Settings" onClick={()=>setScreen('settings')}><Settings/></button><button aria-label="Help" onClick={()=>setScreen('help')}><CircleHelp/></button>{user?.email?.toLowerCase()==='uwajoseph16@gmail.com'&&<button aria-label="Admin dashboard" onClick={openAdmin}>ADM</button>}</div>
    </main>}
    {screen==='game'&&<main className="play-screen">
      <section className="match-score"><div className="player-score"><span className="player-label"><b className="mark-box x-box">X</b><span>{mode==='online'?(room?.players.find(p=>p.mark==='X')?.name||'PLAYER X'):(profile?.username||'YOU')}</span></span><strong>{mode==='online'?(room?.players.find(p=>p.mark==='X')?headToHeadScore.winsByUserId[room.players.find(p=>p.mark==='X')!.userId]||0:0):scores.X}</strong></div><div className="round-status"><b>{mode==='online'?(room?.phase==='lobby'?'WAITING':outcome?(outcome==='draw'?'DRAW GAME':outcome+' WINS'):activeTurn+"'S TURN"):(outcome?statusText:activeTurn+"'S TURN")}</b><span>{mode==='online'?'HEAD-TO-HEAD · '+headToHeadScore.draws+' DRAWS':'ROUND '+round}</span></div><div className="player-score right"><span className="player-label"><span>{mode==='online'?(room?.players.find(p=>p.mark==='O')?.name||'PLAYER O'):(mode==='two'?'PLAYER 2':'COMPUTER')}</span><b className="mark-box o-box">O</b></span><strong>{mode==='online'?(room?.players.find(p=>p.mark==='O')?headToHeadScore.winsByUserId[room.players.find(p=>p.mark==='O')!.userId]||0:0):scores.O}</strong></div></section>
      {mode==='online'&&room&&<div className="online-card room-box main-room-panel"><div><small>ONLINE ROOM · SHARE CODE</small><strong>{room.roomCode}</strong></div><button className="round-icon" onClick={()=>navigator.clipboard?.writeText(room.roomCode)} aria-label="Copy room code"><Copy/></button><div className="room-players">{room.players.map(p=><span key={p.userId}>{p.name} · {p.mark||'…'}</span>)}</div>{room.phase==='lobby'?<><p className="room-wait">{room.players.length<2?'Waiting for your friend to join…':'Both players connected — either player can start. First move is chosen randomly.'}</p>{room.players.length===2&&<button className="big-button quick" onClick={startOnline}>START MATCH</button>}<button className="big-button secondary-button" onClick={()=>setScreen('online')}>ROOM OPTIONS / JOIN ANOTHER ROOM</button></>:<><p className="turn-prompt">{room.phase==='finished'?(room.winner==='draw'?'DRAW GAME':(room.players.find(p=>p.mark===room.winner)?.name||room.winner)+' WINS'):room.turn===myMark?'YOUR TURN':'OPPONENT’S TURN'}</p>{room.phase==='finished'&&<><p className="winner-announcement">{winnerSaying||'🎉 Congratulations! 🎉'}</p><button className="big-button quick" onClick={startNextOnlineRound}>START NEXT ROUND · OTHER SIDE STARTS</button></>}{room.phase==='disconnected'&&<p className="winner-announcement">ROOM DISCONNECTED · {room.winner?(room.winner==='draw'?'DRAW':(room.players.find(p=>p.mark===room.winner)?.name||room.winner)+' WON'):'Match ended before a winner was recorded.'}</p>}{headToHeadHistory.length>0&&<div className="head-to-head"><strong>HEAD-TO-HEAD HISTORY</strong>{headToHeadHistory.slice(0,5).map((m,i)=><p key={m.id||i}>{m.winnerName||m.winner||m.result||'Result unavailable'} · {new Date(m.playedAt).toLocaleDateString()}</p>)}</div>}</>}</div>}
      {mode==='online'&&room&&<section className="online-chat"><button className="chat-heading" onClick={()=>setChatOpen(v=>!v)}>💬 LIVE PLAYER CHAT <span>{chatMessages.length} messages　{chatOpen?'−':'+'}</span></button>{chatOpen&&<><div className="chat-feed" aria-live="polite">{chatMessages.length===0?<p className="chat-empty">Say hello to your opponent 👋</p>:chatMessages.slice(-60).map(message=><div className={'chat-message '+(message.userId===user?.userId?'mine':'theirs')} key={message.id}><small>{message.userId===user?.userId?'You':message.name} · {new Date(message.createdAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</small><p>{message.text}</p></div>)}</div><div className="chat-compose"><button className="emoji-toggle" onClick={()=>setEmojiOpen(v=>!v)} aria-label="Open emoji picker">😀</button><input value={chatText} maxLength={500} onChange={e=>setChatText(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')void sendChat();}} placeholder="Message your opponent…"/><button className="chat-send" disabled={chatSending||!chatText.trim()} onClick={()=>void sendChat()}>{chatSending?'…':'SEND'}</button></div>{emojiOpen&&<div className="emoji-picker"><input className="emoji-search" value={emojiSearch} onChange={e=>setEmojiSearch(e.target.value)} placeholder="Search emoji or category"/>{emojiGroups.filter(g=>!emojiSearch||g.name.toLowerCase().includes(emojiSearch.toLowerCase())||g.items.some(e=>e.includes(emojiSearch))).map(group=><div className="emoji-group" key={group.name}><strong>{group.name}</strong><div>{group.items.filter(e=>!emojiSearch||group.name.toLowerCase().includes(emojiSearch.toLowerCase())||e.includes(emojiSearch)).map((emoji,i)=><button key={group.name+'-'+i} onClick={()=>setChatText(v=>v+emoji)}>{emoji}</button>)}</div></div>)}</div>}</>}</section>}
      {mode!=='online'&&<p className="turn-prompt">{outcome?(outcome==='draw'?'DRAW! NEXT ROUND STARTING…':outcome+' WINS! NEXT ROUND…'):'YOUR TURN - PLACE SYMBOL'}</p>}
      {mode==='solo'&&<div className="difficulty"><label>LEVEL</label><select value={level} onChange={e=>setLevel(e.target.value as Level)}>{levels.map(l=><option key={l}>{l}</option>)}</select></div>}
      {boardView(mode==='online'&&room?room.board:board,mode==='online'?moveOnline:localMove)}
      {paused&&<div className="paused-overlay"><b>GAME PAUSED</b><button className="big-button quick" onClick={()=>setPaused(false)}>RESUME GAME</button></div>}
      <div className="play-controls">{mode!=='online'&&<><button onClick={()=>setPaused(!paused)}><Pause size={18}/>{paused?'RESUME':'PAUSE'}</button><button onClick={reset}><RotateCcw size={18}/> RESTART</button></>}<button className="sound-button" aria-label="Toggle sound" onClick={()=>setSound(!sound)}>{sound?<Volume2/>:<VolumeX/>}</button></div><p className="game-footnote">{mode==='online'?'Online multiplayer uses this same main board as Quick Match. Keep the room open while playing.':'Round automatically restarts after 2.2 seconds · Sounds can be muted.'}</p>
    </main>}
    {screen==='online'&&<main className="sub-screen lobby-screen">
      <div className="lobby-hero"><div className="wire-cube"></div><div className="lobby-heading"><h1>ONLINE LOBBY</h1><button onClick={goHome}>Back</button></div></div>
      <section className="profile-card"><small>MY PROFILE</small><strong>{profile?.username}</strong><span className="online-status">● ONLINE</span><span className="profile-email">{user?.email}</span></section>
      <label className="field-label">USERNAME</label><input className="lobby-input" value={name} onChange={e=>setName(e.target.value)} maxLength={20}/><button className="big-button quick" onClick={saveProfile}>SAVE PROFILE</button>
      <button className="big-button secondary-button" onClick={()=>setScreen('friends')}>CHANGE USERNAME / FIND FRIENDS</button>
      <label className="field-label">PLAY WITH FRIEND</label><div className="friend-search"><input value={searchName} onChange={e=>setSearchName(e.target.value)} placeholder="Search username"/><button onClick={findFriend}><Search size={18}/> Find</button></div>
      {foundProfiles.map(p=><div className="search-result" key={p.userId}><div><strong>{p.username}</strong><small>{p.email||'Native X & O player'}</small></div><button onClick={()=>void sendInvite(p.userId,p.username)}>INVITE</button></div>)}{inviteData.friends.length>0&&<div className="online-card"><h2>SAVED FRIENDS</h2>{inviteData.friends.map(friend=><div className="search-result" key={friend.userId}><strong>{friend.username}</strong><button onClick={()=>void sendInvite(friend.userId,friend.username)}>CHALLENGE</button></div>)}</div>}
      <p className="lobby-hint">{room?(room.phase==='playing'?'MATCH LIVE — PLAY BELOW. Keep this screen open.':'Share this private room code with your friend.'):'Create your profile to enter the live room.'}</p>
      {!room?<div className="lobby-actions"><button className="big-button multiplayer" onClick={makeRoom}>CREATE LIVE ROOM</button><div className="friend-search"><input value={roomCode} onChange={e=>setRoomCode(e.target.value)} placeholder="Enter room code" maxLength={12}/><button onClick={joinRoom}>JOIN</button></div></div>:<div className="online-card room-box"><div><small>ROOM CODE</small><strong>{room.roomCode}</strong></div><button className="round-icon" onClick={()=>navigator.clipboard?.writeText(room.roomCode)}><Copy/></button><div className="room-players">{room.players.map(p=><span key={p.userId}>{p.name} · {p.mark||'…'}</span>)}</div>{room.phase==='lobby'?<><p className="room-wait">{room.players.length<2?'Waiting for your friend to join…':'Both players connected — either player can start. First turn is random.'}</p>{room.players.length===2&&<button className="big-button quick" onClick={startOnline}>START MATCH</button>}</>:<><p className="turn-prompt">{room.phase==='finished'?(room.winner==='draw'?'DRAW GAME':(room.players.find(p=>p.mark===room.winner)?.name||room.winner)+' WINS'):room.turn===myMark?'YOUR TURN':'OPPONENT’S TURN'}</p>{room.phase==='finished'&&<><p className="winner-announcement">{winnerSaying||'🎉 Congratulations! 🎉'}</p><button className="big-button quick" onClick={startNextOnlineRound}>START NEXT ROUND · OTHER SIDE STARTS</button></>}{room.phase==='disconnected'&&<p className="winner-announcement">ROOM DISCONNECTED · {room.winner?(room.winner==='draw'?'DRAW':(room.players.find(p=>p.mark===room.winner)?.name||room.winner)+' WON'):'Match ended before a winner was recorded.'}</p>}{headToHeadHistory.length>0&&<div className="head-to-head"><strong>HEAD-TO-HEAD HISTORY</strong>{headToHeadHistory.slice(0,5).map((m,i)=><p key={m.id||i}>{m.winnerName||m.winner||m.result||'Result unavailable'} · {new Date(m.playedAt).toLocaleDateString()}</p>)}</div>}{room.phase!=='disconnected'&&boardView(room.board,moveOnline)}</>}</div>}
      <button className="big-button secondary-button" onClick={installApp}>{isInstalled?'INSTALLED':installPrompt?'INSTALL APP':'ADD TO PHONE'}</button><button className="signout-link" onClick={signOut}>SIGN OUT</button>
    </main>}
    {screen==='friends'&&<main className="sub-screen"><section className="section-heading"><h1>FRIENDS &amp; CHALLENGES</h1><p>Find players by username or invite them to a private room.</p></section><div className="online-card"><Users className="section-icon"/><label className="field-label">SEARCH USERNAME</label><div className="friend-search"><input value={searchName} onChange={e=>setSearchName(e.target.value)} placeholder="Search username"/><button onClick={findFriend}>Find</button></div>{foundProfiles.map(p=><div className="search-result" key={p.userId}><strong>{p.username}</strong><button onClick={()=>void sendInvite(p.userId,p.username)}>SEND INVITE</button></div>)}<h2>INVITATIONS FOR YOU</h2>{inviteData.incoming.length===0?<p>No pending invitations right now.</p>:inviteData.incoming.map(invite=><div className="search-result" key={invite.id}><div><strong>{invite.fromName}</strong><small>Wants to play with you</small></div><div><button onClick={()=>void respondInvite(invite.id,'accept',invite.fromName)}>ACCEPT</button><button onClick={()=>void respondInvite(invite.id,'decline',invite.fromName)}>DECLINE</button></div></div>)}<h2>SAVED FRIENDS</h2>{inviteData.friends.length===0?<p>Accepted invitations will be saved here for next time.</p>:inviteData.friends.map(friend=><div className="search-result" key={friend.userId}><div><strong>{friend.username}</strong><small>Saved friend</small></div><button onClick={()=>void sendInvite(friend.userId,friend.username)}>CHALLENGE</button></div>)}<h2>INVITATION STATUS</h2>{inviteData.outgoing.filter(i=>i.status!=='declined').slice(0,8).map(invite=><div className="admin-row" key={invite.id}><strong>{invite.toName}</strong><span>{invite.status==='accepted'?'Accepted — saved as friends':invite.status==='pending'?'Waiting for response':'Invitation '+invite.status}</span></div>)}<button className="big-button multiplayer" onClick={()=>setScreen('online')}>OPEN ONLINE LOBBY</button><button className="big-button quick" onClick={()=>startGame('two')}>PLAY ON THIS PHONE</button></div></main>}
    {screen==='stats'&&<main className="sub-screen"><section className="section-heading"><h1>YOUR RECORD</h1><p>Scores from this session</p></section><div className="stats-grid"><div><span>X WINS</span><strong>{scores.X}</strong></div><div><span>DRAWS</span><strong>{scores.draw}</strong></div><div><span>O WINS</span><strong>{scores.O}</strong></div></div><button className="big-button quick" onClick={goHome}>BACK HOME</button></main>}
    {screen==='settings'&&<main className="sub-screen"><section className="section-heading"><h1>SETTINGS</h1><p>Personalize your arena.</p></section><div className="online-card setting-row"><span>My symbol</span><div className="symbol-choice"><button className={'toggle '+(preferredMark==='X'?'on':'')} onClick={()=>setPreferredMark('X')}>X</button><button className={'toggle '+(preferredMark==='O'?'on':'')} onClick={()=>setPreferredMark('O')}>O</button></div></div><p className="settings-note">Your symbol preference is saved to your player profile when you tap Save Profile in the lobby, or save it below.</p><button className="big-button quick" onClick={saveProfile}>SAVE SETTINGS</button><div className="online-card"><div className="setting-row"><span>Game sound</span><button className={'toggle '+(sound?'on':'')} onClick={()=>setSound(!sound)}>{sound?'ON':'OFF'}</button></div><label className="volume-control"><span>Volume boost</span><strong>{volume}%</strong><input aria-label="Game sound volume" type="range" min="0" max="100" step="5" value={volume} onChange={e=>setVolume(Number(e.target.value))}/><small>Controls your device's in-game volume only. The app can boost and limit its own music, but cannot override Android system volume or make other apps quieter.</small></label><p className="settings-note">Shared track: {globalMusicTitle}</p><button className="big-button secondary-button" onClick={()=>playSound('click')}>TEST SOUND</button></div><div className="online-card setting-row"><span>Computer difficulty</span><select value={level} onChange={e=>setLevel(e.target.value as Level)}>{levels.map(l=><option key={l}>{l}</option>)}</select></div><button className="big-button secondary-button" onClick={installApp}>{isInstalled?'INSTALLED':installPrompt?'INSTALL APP':'ADD TO PHONE'}</button><button className="big-button secondary-button" onClick={signOut}>SIGN OUT</button></main>}
    {screen==='admin'&&<main className="sub-screen admin-screen"><section className="section-heading"><h1>ADMIN CONTROL</h1><p>Private dashboard · registered players and game activity</p></section>{adminLoading?<div className="online-card">Loading secured admin data…</div>:adminOverview&&<><div className="stats-grid"><div><span>REGISTERED USERS</span><strong>{adminOverview.users.length}</strong></div><div><span>GAMES RECORDED</span><strong>{adminOverview.matches.length}</strong></div><div><span>ACTIVE ROOMS</span><strong>{adminOverview.activeRooms.length}</strong></div></div><section className="online-card"><h2>GLOBAL BACKGROUND MUSIC</h2><p>Upload an audio file to change the background music for every player. Supported files include MP3, WAV, OGG and M4A when the browser supports them; maximum size 8 MB.</p><div className="admin-row"><strong>Current track</strong><span>{globalMusicTitle}</span></div><label className="field-label" htmlFor="admin-music-file">CHOOSE AUDIO FILE</label><input id="admin-music-file" type="file" accept="audio/*,.mp3,.wav,.ogg,.m4a" disabled={musicUploadBusy} onChange={e=>{const file=e.currentTarget.files?.[0];void uploadGlobalMusic(file);e.currentTarget.value='';}}/><p className="small-note">{musicUploadBusy?'Uploading '+musicUploadName+'…':'Only the registered admin can replace the shared track. Each player still controls their own volume in Settings.'}</p><label className="volume-control"><span>Admin preview volume</span><strong>{volume}%</strong><input aria-label="Admin music preview volume" type="range" min="0" max="100" step="5" value={volume} onChange={e=>setVolume(Number(e.target.value))}/></label></section><section className="online-card"><h2>Registered users</h2>{adminOverview.users.map(p=><div className="admin-row" key={p.userId}><strong>{p.username}</strong><span>{p.email||'Email unavailable'}</span><small>Preferred symbol: {p.preferredMark||'X'}</small></div>)}</section><section className="online-card"><h2>Player-versus-player history</h2><p>Pair records update automatically every 2 seconds. Wins and losses are shown from each player's perspective.</p>{!adminOverview.pairHistory?.length?<p>No completed online head-to-head matches recorded yet.</p>:adminOverview.pairHistory.map((pair,i)=><div className="admin-row" key={pair.player1Id+'-'+pair.player2Id}><strong>{pair.player1Name} vs {pair.player2Name}</strong><span>Played: {pair.played} · Draws: {pair.draws}</span><small>{pair.player1Name}: {pair.player1Wins} wins, {pair.player2Wins} losses · {pair.player2Name}: {pair.player2Wins} wins, {pair.player1Wins} losses</small><small>Last played: {pair.lastPlayedAt?new Date(pair.lastPlayedAt).toLocaleString():'—'}</small></div>)}</section><section className="online-card"><h2>Active online games</h2>{adminOverview.activeRooms.length===0?<p>No active online rooms right now.</p>:adminOverview.activeRooms.map(r=><div className="admin-row" key={r.roomCode}><strong>Room {r.roomCode} · {r.phase.toUpperCase()}</strong><span>{r.players.map(p=>p.name+' ('+(p.mark||'?')+')').join(' vs ')}</span><small>Turn: {r.turn}</small></div>)}</section><button className="big-button secondary-button" onClick={openAdmin}>REFRESH ADMIN DATA</button></> }<button className="big-button quick" onClick={goHome}>BACK HOME</button></main>}
    {screen==='help'&&<main className="sub-screen"><section className="section-heading"><h1>HOW TO PLAY</h1><p>Simple rules. Smart moves.</p></section><div className="online-card"><h2>Make three in a row</h2><p>Place X or O in an empty square. Get three symbols in a horizontal, vertical, or diagonal line to win. Impossible uses optimal play.</p><button className="big-button quick" onClick={()=>startGame('solo')}>START PLAYING</button></div></main>}
    {notice&&<button className="notice-pill" onClick={()=>setNotice('')}>{notice}　×</button>}
  </div>;
}
export default App;